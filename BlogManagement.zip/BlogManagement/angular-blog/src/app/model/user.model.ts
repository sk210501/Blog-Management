
export interface User{
    about: string;
    dob: string;
    role: string;
    userEmail: string;
    userId: number;
    userName: string;
    userPassword: string;
}